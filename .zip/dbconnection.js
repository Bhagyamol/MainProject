const mongoose = require('mongoose')
const url="mongodb+srv://visakhts:427799@cluster0.70uir.mongodb.net/<sublet>?retryWrites=true&w=majority"
//  const url=process.env.MONGO_LOCAL;

mongoose.connect(url, {useNewUrlParser: true},(err)=>{
    if(!err) return console.log("MongoDB connected");
    else{
        console.log(err);
        console.log(request.body);
    }
});