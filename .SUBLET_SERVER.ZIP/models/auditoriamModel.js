const mongoose = require('mongoose');
const Schema   = mongoose.Schema;

const auditoriamSchema=new Schema({
    address:String,
    location:String,
    Price:Number,
    date_from:Date,
    date_to:Date,
    Deatils:String,
    is_booked:Boolean
})
const auditoriam= mongoose.model('auditoriam',auditoriamSchema);
module.exports=auditoriam;
