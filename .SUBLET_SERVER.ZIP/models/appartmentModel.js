const mongoose = require('mongoose');
const Schema   = mongoose.Schema;

const appartmentSchema=new Schema({
    address:String,
    location:String,
    Price:Number,
    date_from:Date,
    date_to:Date,
    Deatils:String,
    is_booked:Boolean
})
const appartment= mongoose.model('appartment',appartmentSchema);
module.exports=appartment;
