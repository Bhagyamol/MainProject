const mongoose = require('mongoose');
const Schema   = mongoose.Schema;
const bookingSchema=new mongoose.Schema({
    user_id:String,
    apartment_id:String,
    Price:Number,
    date_from:Date,
    date_to:Date,
    is_booked:Boolean
    })
const booking= mongoose.model('booking',bookingSchema);
module.exports=booking;
    