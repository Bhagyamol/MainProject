const express = require('express')  //importing express package into a variable
const server  = express();    //creating an http server by calling the function express()
const port =8000;         //specifying a port for running the server


server.listen(port,function(){
      console.log("Your server is running on port 8000")
})