var express = require('express');
var router = express.Router();

router.get('/',(req,res)=>{
  console.log("Working fine");
  res.send("Working fine")
})
//*user routes*


//signin


//signup

//forgot password

//view all apartment/guesthouse/auditorium

//view apartment/guesthouse/auditorium
//book apartment/guesthouse/auditorium
//view my rentals


//*vendor routes*

//add  apartment/guesthouse/auditorium

//edit apartment/guesthouse/auditorium

//delete apartment/guesthouse/auditorium




//*admin routes*

//view all users

//view all vendors

//approve items uploaded by vendor

//view all apartment/guesthouse/auditorium

//view apartment/guesthouse/auditorium

//view all rentals






module.exports = router;

