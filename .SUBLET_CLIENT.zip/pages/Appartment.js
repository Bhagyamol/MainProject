import React from 'react'
import { styled, alpha } from '@mui/material/styles';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import InputBase from '@mui/material/InputBase';
import MenuIcon from '@mui/icons-material/Menu';
import SearchIcon from '@mui/icons-material/Search';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';


const Search = styled('div')(({ theme }) => ({
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: alpha(theme.palette.common.white, 0.15),
    '&:hover': {
      backgroundColor: alpha(theme.palette.common.white, 0.25),
    },
    marginLeft: 0,
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(1),
      width: 'auto',
    },
  }));
  
  const SearchIconWrapper = styled('div')(({ theme }) => ({
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  }));
  
  const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: 'inherit',
    '& .MuiInputBase-input': {
      padding: theme.spacing(1, 1, 1, 0),
      // vertical padding + font size from searchIcon
      paddingLeft: `calc(1em + ${theme.spacing(4)})`,
      transition: theme.transitions.create('width'),
      width: '100%',
      [theme.breakpoints.up('sm')]: {
        width: '12ch',
        '&:focus': {
          width: '20ch',
        },
      },
    },
  }));
function Appartment() {
  return (
    <div>
       <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static">
        <Toolbar>
          <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="open drawer"
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          <Typography
            variant="h6"
            noWrap
            component="div"
            sx={{ flexGrow: 2, display: { xs: 'none', sm: 'block' } }}
          >
        <h1 class="font-medium leading-tight text-center text-2xl mt-0 mb-2 text-white-600 pt-4">VILLAS & APPARTMENTS</h1>
          </Typography>
          <Search>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search…"
              inputProps={{ 'aria-label': 'search' }}
            />
          </Search>
        </Toolbar>
      </AppBar>
    </Box>
    <div>
    <div class="grid grid-cols-6 gap-5 p-20 ">
                    <div
                        class="col-span-6 mt-5 bg-opacity-50 border border-gray-100 rounded shadow-lg cursor-pointer bg-gradient-to-b from-gray-200 backdrop-blur-20 to-gray-50 md:col-span-3 lg:col-span-2 ">
                        <div class="flex flex-row px-2 py-3 mx-3">
    
                            <div class="flex flex-col mt-1 mb-2 ml-4">
                                <div class="text-sm text-green-600">Villas</div>
                                <div class="flex w-full mt-1">
                                    <div class="mr-1 text-xs text-blue-700 cursor-pointer font-base">
                                        Kottayam
                                    </div>
                                    <div class="text-xs text-gray-600">
                                        • Thirunakkara
                                    </div>
                                </div>
                            </div>
                        </div>
    
                        <div class="flex justify-center px-2 mx-3 my-2 text-sm font-medium text-gray-400">
                            <img class="w-[300px] h-[300px] rounded-full shadow-2xl object-cover"
                                src="https://teja8.kuikr.com//r1/20190604/ak_556_72395540-1559639859_700x700.png"/>
    
                        </div>
    
                        <div class="mb-5 border-t border-gray-50">
                            <div class="flex flex-wrap justify-start mx-5 mt-6 text-xs sm:justify-center ">
                                <div class="flex mb-2 mr-4 font-normal text-black-700 ">$5000<div
                                        class="ml-1 text-yellow-500 text-ms"> /Month</div>
                                </div>
                                <div class="flex mb-2 mr-4 font-normal text-black-700 ">Fully Furnished Villa <div
                                        class="ml-1 text-gray-500 text-ms"> </div>
                                </div>
                               
       
                                <div class="flex mb-2 mr-4 text-red-700 ">Available Now !!! <div
                                        class="ml-1 text-gray-500 text-ms"> </div>
                                </div>
                                <button type="button" class="inline-block px-6 py-2.5 bg-green-600 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-purple-700 hover:shadow-lg focus:bg-purple-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-purple-800 active:shadow-lg transition duration-150 ease-in-out">View Details</button>
        
                            </div>
    
                        </div>
    
                    </div>
                    <div
                        class="col-span-6 mt-5 bg-opacity-50 border border-gray-100 rounded shadow-lg cursor-pointer bg-gradient-to-b from-gray-200 backdrop-blur-20 to-gray-50 md:col-span-3 lg:col-span-2 ">
                        <div class="flex flex-row px-2 py-3 mx-3">
    
                            <div class="flex flex-col mt-1 mb-2 ml-4">
                                <div class="text-sm text-green-600">Villas</div>
                                <div class="flex w-full mt-1">
                                    <div class="mr-1 text-xs text-blue-700 cursor-pointer font-base">
                                        Kottayam
                                    </div>
                                    <div class="text-xs text-gray-600">
                                        • KanjiKuzhi
                                    </div>
                                </div>
                            </div>
                        </div>
    
                        <div class="flex justify-center px-2 mx-3 my-2 text-sm font-medium text-gray-400">
                            <img class="w-[300px] h-[300px] rounded-full shadow-2xl object-cover"
                                src="https://is1-2.housingcdn.com/4f2250e8/997cae147b07011ef9bf8e599da4362c/v0/fs.jpeg"/>
    
                        </div>
    
                        <div class="mb-5 border-t border-gray-100">
                            <div class="flex flex-wrap justify-start mx-5 mt-6 text-xs sm:justify-center ">
                                <div class="flex mb-2 mr-4 font-normal text-black-1000 ">$6000<div
                                        class="ml-1 text-yellow-500 text-ms">/Month</div>
                                </div>
                                <div class="flex mb-2 mr-4 font-normal text-black-700 ">Fully Furnished villa<div
                                        class="ml-1 text-gray-500 text-ms"> </div>
                                </div>
                                
                           <div class="flex mb-2 mr-4 text-red-700 "> Available Now !!!<div
                                        class="ml-1 text-gray-500 text-ms"> </div>
                                </div>
                                <button type="button" class="inline-block px-6 py-2.5 bg-green-600 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-purple-700 hover:shadow-lg focus:bg-purple-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-green-800 active:shadow-lg transition duration-150 ease-in-out">View Details</button>
             
                            </div>
    
                        </div>
    
                    </div>
                    <div
                        class="col-span-6 mt-5 bg-opacity-50 border border-gray-100 rounded shadow-lg cursor-pointer bg-gradient-to-b from-gray-200 backdrop-blur-20 to-gray-50 md:col-span-3 lg:col-span-2 ">
                        <div class="flex flex-row px-2 py-3 mx-3">
    
                            <div class="flex flex-col mt-1 mb-2 ml-4">
                                <div class="text-sm text-green-600">Villas</div>
                                <div class="flex w-full mt-1">
                                    <div class="mr-1 text-xs text-blue-700 cursor-pointer font-base">
                                        Kottayam
                                    </div>
                                    <div class="text-xs text-gray-600">
                                        • Nagambadam
                                    </div>
                                </div>
                            </div>
                        </div>
    
                        <div class="flex justify-center px-2 mx-3 my-2 text-sm font-medium text-gray-400">
                            <img class="w-[300px] h-[300px] rounded-full shadow-2xl object-cover "
                                src="https://www.kcchomes.com/wp-content/uploads/2021/10/grand.jpg"/>
    
                        </div>
    
                        <div class="mb-5 border-t border-gray-100">
                            <div class="flex flex-wrap justify-start mx-5 mt-6 text-xs sm:justify-center ">
                                <div class="flex mb-2 mr-4 font-normal text-gray-700 ">$10000<div
                                        class="ml-1 text-yellow-500 text-ms"> /Month</div>
                                </div>
                                <div class="flex mb-2 mr-4 font-normal text-gray-700 ">Fully Furnished Villa<div
                                        class="ml-1 text-gray-500 text-ms"></div>
                                </div>
                                
                         <div class="flex mb-2 mr-4 text-red-700 ">Available After 6 month !!! <div
                                        class="ml-1 text-gray-500 text-ms"> </div>
                                </div>
                                <button type="button" class="inline-block px-6 py-2.5 bg-green-600 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-purple-700 hover:shadow-lg focus:bg-purple-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-purple-800 active:shadow-lg transition duration-150 ease-in-out">View Details</button>
              
                            </div>
    
                        </div>
    
                    </div>
    
    
                </div>      
                </div>
                <div>
    <div class="grid grid-cols-6 gap-5 p-20 ">
                    <div
                        class="col-span-6 mt-5 bg-opacity-50 border border-gray-100 rounded shadow-lg cursor-pointer bg-gradient-to-b from-gray-200 backdrop-blur-20 to-gray-50 md:col-span-3 lg:col-span-2 ">
                        <div class="flex flex-row px-2 py-3 mx-3">
    
                            <div class="flex flex-col mt-1 mb-2 ml-4">
                                <div class="text-sm text-green-600">Appartments</div>
                                <div class="flex w-full mt-1">
                                    <div class="mr-1 text-xs text-blue-700 cursor-pointer font-base">
                                        Kottayam
                                    </div>
                                    <div class="text-xs text-gray-600">
                                        • Thirunakkara
                                    </div>
                                </div>
                            </div>
                        </div>
    
                        <div class="flex justify-center px-2 mx-3 my-2 text-sm font-medium text-gray-400">
                            <img class="w-[300px] h-[300px] rounded-full shadow-2xl object-cover"
                                src="https://archello.s3.eu-central-1.amazonaws.com/images/2018/05/10/1.Free-Apartment-interior-design--tobiarchitects--architect.1525960960.7883.jpg"/>
    
                        </div>
    
                        <div class="mb-5 border-t border-gray-50">
                            <div class="flex flex-wrap justify-start mx-5 mt-6 text-xs sm:justify-center ">
                                <div class="flex mb-2 mr-4 font-normal text-gray-700 ">$2500<div
                                        class="ml-1 text-yellow-500 text-ms"> /Month</div>
                                </div>
                                <div class="flex mb-2 mr-4 font-normal text-black-700 ">Fully Furnished Appartments <div
                                        class="ml-1 text-gray-500 text-ms"> </div>
                                </div>
                                <div class="flex mb-2 mr-4 text-red-700 ">Available Now !!!<div
                                        class="ml-1 text-gray-500 text-ms"> </div>
                                </div>
                                <button type="button" class="inline-block px-6 py-2.5 bg-green-600 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-purple-700 hover:shadow-lg focus:bg-purple-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-purple-800 active:shadow-lg transition duration-150 ease-in-out">View Details</button>
              
                            </div>
    
                        </div>
    
                    </div>
                    <div
                        class="col-span-6 mt-5 bg-opacity-50 border border-gray-100 rounded shadow-lg cursor-pointer bg-gradient-to-b from-gray-200 backdrop-blur-20 to-gray-50 md:col-span-3 lg:col-span-2 ">
                        <div class="flex flex-row px-2 py-3 mx-3">
    
                            <div class="flex flex-col mt-1 mb-2 ml-4">
                                <div class="text-sm text-green-600">Appartment</div>
                                <div class="flex w-full mt-1">
                                    <div class="mr-1 text-xs text-blue-700 cursor-pointer font-base">
                                        Kottayam
                                    </div>
                                    <div class="text-xs text-gray-600">
                                        • Ettumanoor
                                    </div>
                                </div>
                            </div>
                        </div>
    
                        <div class="flex justify-center px-2 mx-3 my-2 text-sm font-medium text-gray-400">
                            <img class="w-[300px] h-[300px] rounded-full shadow-2xl object-cover"
                                src="https://amazingarchitecture.com/storage/739/The-Angel-Empire-by-YODEZEEN-Amazing-Architecture.jpg"/>
    
                        </div>
    
                        <div class="mb-5 border-t border-gray-100">
                            <div class="flex flex-wrap justify-start mx-5 mt-6 text-xs sm:justify-center ">
                                <div class="flex mb-2 mr-4 font-normal text-gray-700 ">$5000<div
                                        class="ml-1 text-yellow-500 text-ms">/month</div>
                                </div>
                                <div class="flex mb-2 mr-4 font-normal text-gray-700 ">Fully Furnished<div
                                        class="ml-1 text-gray-500 text-ms"> </div>
                                </div>
                                <div class="flex mb-2 mr-4 text-red-700 ">Available Now !!! <div
                                        class="ml-1 text-gray-500 text-ms"> </div>
                                </div>
                                <button type="button" class="inline-block px-6 py-2.5 bg-green-600 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-purple-700 hover:shadow-lg focus:bg-purple-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-purple-800 active:shadow-lg transition duration-150 ease-in-out">View Details</button>
              
                            </div>
    
                        </div>
    
                    </div>
                    <div
                        class="col-span-6 mt-5 bg-opacity-50 border border-gray-100 rounded shadow-lg cursor-pointer bg-gradient-to-b from-gray-200 backdrop-blur-20 to-gray-50 md:col-span-3 lg:col-span-2 ">
                        <div class="flex flex-row px-2 py-3 mx-3">
    
                            <div class="flex flex-col mt-1 mb-2 ml-4">
                                <div class="text-sm text-green-600">Appartment</div>
                                <div class="flex w-full mt-1">
                                    <div class="mr-1 text-xs text-blue-700 cursor-pointer font-base">
                                        Kottayam
                                    </div>
                                    <div class="text-xs text-gray-600">
                                        • Ettumanoor
                                    </div>
                                </div>
                            </div>
                        </div>
    
                        <div class="flex justify-center px-2 mx-3 my-2 text-sm font-medium text-gray-400">
                            <img class="w-[300px] h-[300px] rounded-full shadow-2xl object-cover "
                                src="http://www.caandesign.com/wp-content/uploads/2015/07/Apartment-Kiev-05.jpg"/>
    
                        </div>
                        <div class="mb-5 border-t border-gray-100">
                            <div class="flex flex-wrap justify-start mx-5 mt-6 text-xs sm:justify-center ">
                                <div class="flex mb-2 mr-4 font-normal text-gray-700 ">$5000<div
                                        class="ml-1 text-yellow-500 text-ms">/month</div>
                                </div>
                                <div class="flex mb-2 mr-4 font-normal text-gray-700 ">Fully Furnished<div
                                        class="ml-1 text-gray-500 text-ms"> </div>
                                </div>
                                <div class="flex mb-2 mr-4 text-red-700 ">Available Now !!! <div
                                        class="ml-1 text-gray-500 text-ms"> </div>
                                </div>
                                <button type="button" class="inline-block px-6 py-2.5 bg-green-600 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-purple-700 hover:shadow-lg focus:bg-purple-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-purple-800 active:shadow-lg transition duration-150 ease-in-out">View Details</button>
              
                            </div>
    
                        </div>
    
                    </div>
    
                        
    
                </div>      
                </div>
                </div>
  
              
  )
  
  }

export default Appartment

