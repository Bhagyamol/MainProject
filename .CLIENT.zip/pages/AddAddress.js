import React from 'react'
import { useState } from 'react'
import  UserNavbar from '../Components/userNavbar'
import axios from 'axios'
import {useRouter} from 'next/router'
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import Swal from 'sweetalert2';
function AddAddress() {
  const Toast = Swal.mixin({
    toast: true,
    position: "top-right",
    iconColor: "white",
    customClass: {
      popup: "colored-toast",
    },
    showConfirmButton: false,
    timer: 1500,
    timerProgressBar: true,
  });

    const router = useRouter();
    const [loading,setLoading]=useState(false);
    const[address,setAddress]=useState({
        house_name:"",
        district:"",
        state:"",
        country:"",
        city:"",
        street:"",
        postal_code:""
    })
    const handleChange=(e)=>{
      setAddress({...address,[e.target.name]:e.target.value})
    }
    const handleSubmit=()=>{
      console.log(address);
  if((address.house_name=="" ||address.district=="" ||address.state=="" || address.city=="" ||address.street==""||address.postal_code=="" ) && !(isNaN( address.postal_code)) ){
    Toast.fire({
      icon: "error",
      title: "Please give a valid input...!!",
    });
  }
  else{
    
    var u_id=localStorage.getItem("user_id");
    if(u_id && address){
      setLoading(true);
      axios.post('http://localhost:5000/user/addAddress',{address,u_id}).then((resp)=>{
         if(resp.data.success){
           setLoading(false)
           router.push('/Categories')
         }
         else{
          setLoading(false) 

         }
      }).catch((err)=>{
           setLoading(false)
         
      })
    }
    else{
      alert("error")
    }
   
  }




     
    }
  return (
    <div>

       <UserNavbar/>
       {
        loading?
        <Backdrop
        sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={true}
        
      >
        <CircularProgress color="inherit" />
      </Backdrop>:
      <>
      <h3 class="font-medium leading-tight text-center text-2xl mt-0  text-blue pt-4">ADD ADDRESS</h3>

<div style={{width:"1000px",height:"600px",marginLeft:"400px",marginTop:"20px"}}  >
 <div className="md:grid md:grid-cols-3 md:gap-6">

   
   <div className="mt-3 md:mt-0 md:col-span-2">
     <div>
       <div className="shadow overflow-hidden sm:rounded-md"  >
         <div className="px-4 py-5 bg-white sm:p-6" style={{backgroundColor:"#ededed"}}>
           <div className="grid grid-cols-6 gap-6">
             <div className="col-span-6 sm:col-span-3">
               <label htmlFor="first-name" className="block text-sm font-medium text-gray-700">
                House Name
               </label>
               <input
                 type="text"
                 name="house_name"
                 
                 onChange={handleChange}
                 id="first-name"
                 autoComplete="given-name"
                 className="pt-2 pb-2 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-500 rounded-md"
               />
             </div>

             <div className="col-span-6 sm:col-span-3">
               <label htmlFor="last-name" className="block text-sm font-medium text-gray-700">
                 District
               </label>
               <input
                 type="text"
                 name="district"
                 onChange={handleChange}
                 id="last-name"
                 autoComplete="family-name"
                 className="pt-2  pb-2 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
               />
             </div>
             <div className="col-span-6 sm:col-span-3">
               <label htmlFor="first-name" className="block text-sm font-medium text-gray-700">
                State
               </label>
               <input
                 type="text"
                 name="state"
                 onChange={handleChange}
                 id="first-name"
                 autoComplete="given-name"
                 className="pt-2  pb-2 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
               />
             </div>

             <div className="col-span-6 sm:col-span-3">
               <label htmlFor="last-name" className="block text-sm font-medium text-gray-700">
                 Country
               </label>
               <input
                 type="text"
                 name="country"
                 onChange={handleChange}
                 id="last-name"
                 autoComplete="family-name"
                 className="pt-2  pb-2 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
               />
             </div>

             

             
             

             <div className="col-span-6 sm:col-span-6 lg:col-span-2">
               <label htmlFor="city" className="block text-sm font-medium text-gray-700">
                 City
               </label>
               <input
                 type="text"
                 name="city"
                 onChange={handleChange}
                 id="city"
                 autoComplete="address-level2"
                 className="pt-2  pb-2 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
               />
             </div>

             <div className="col-span-6 sm:col-span-3 lg:col-span-2">
               <label htmlFor="region" className="block text-sm font-medium text-gray-700">
                 Street
               </label>
               <input
                 type="text"
                 name="street"
                 onChange={handleChange}
                 id="region"
                 autoComplete="address-level1"
                 className="pt-2  pb-2 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
               />
             </div>

             <div className="col-span-6 sm:col-span-3 lg:col-span-2">
               <label htmlFor="postal-code" className="block text-sm font-medium text-gray-700">
                 Postal code
               </label>
               <input
                 type="number"
                 name="postal_code"
                 onChange={handleChange}
                 id="postal-code"
                 autoComplete="postal-code"
                 className="pt-2 pb-2 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
               />
             </div>
           </div>
         </div>
        
         <div className="px-4 py-3 bg-gray-50 text-right sm:px-6">
           <button
             onClick={handleSubmit}
             className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
           >
             Submit
           </button>
         </div>
       </div>
     </div>
   </div>
 </div>
 </div>
      </>
       }
       
    </div>
  )
}

export default AddAddress