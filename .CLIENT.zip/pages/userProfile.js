import React from 'react'
import  UserNavbar from '../Components/userNavbar'
import axios from 'axios'
function userProfile() {

    const [user,setUser]=React.useState([])
    const [address,setAddress]=React.useState([])

    React.useEffect(()=>{
        let user_id=localStorage.getItem("user_id")
        if(user_id){
          axios.post('http://localhost:5000/user/getUser',{user_id}).then((resp)=>{
            if(resp.data.success){
              setUser(resp.data.user)
              setAddress(resp.data.address)
              
            }
          })
     
        }
       },[])
  return (
    <div>
        <UserNavbar/>
        <div className="bg-white shadow overflow-hidden sm:rounded-lg pl-8 " style={{ width: "600px", margin: "auto", marginTop: "30px" }}>
              <div className="px-4 py-5 sm:px-6">
                <h3 className="text-lg leading-6 font-medium text-gray-900">🙎🏼‍♂️User Information</h3>
              </div>
              <div className="border-t border-gray-200">
                <dl>
                  <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">Full name</dt>
                    <dd className="mt-1 text-sm text-black-500 sm:mt-0 sm:col-span-2">
                      <span class="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-blue-600 text-white rounded-full"> {user.name}</span>

                    </dd>
                  </div>
                  <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">📩Email </dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{user.email}</dd>
                  </div>
                  <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">☎️Phone number </dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{user.phone}</dd>
                  </div>
                  
                    

            <div className="bg-white shadow overflow-hidden sm:rounded-lg pl-8 " style={{ width: "600px", margin: "auto", marginTop: "30px" }}>
              <div className="px-4 py-5 sm:px-6">
                <h3 className="text-lg leading-6 font-medium text-gray-900">Address</h3>
              </div>

              <div className="border-t border-gray-200">
               
                    <dl>


                     
                      <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">House Name</dt>
                        <dd className="mt-1 text-sm text-black-500 sm:mt-0 sm:col-span-2">
                          <span class="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-black-500 text-black rounded-full">{address.house_name}</span>

                        </dd>
                      </div>
                      <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">District </dt>
                        <dd>

                          <span class="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-black-500 text-black rounded-full">{address.district}</span>
                        </dd>

                      </div>
                      <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">State </dt>
                        <dd>

                          <span class="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-black-500 text-black rounded-full">{address.state}</span>
                        </dd>

                      </div>
                      <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">Country </dt>
                        <dd>

                          <span class="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-black-500 text-black rounded-full">{address.country}</span>
                        </dd>

                      </div>
                      <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">City </dt>
                        <dd>

                          <span class="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-black-500 text-black rounded-full">{address.city}</span>
                        </dd>

                      </div>
                      <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">Street </dt>
                        <dd>

                          <span class="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-black-500 text-black rounded-full">{address.street}</span>
                        </dd>

                      </div>    
                      <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                        <dt className="text-sm font-medium text-gray-500">Pin code </dt>
                        <dd>

                          <span class="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-black-500 text-black rounded-full">{address.postal_code}</span>
                        </dd>

                      </div>                 



                    </dl> 

              </div>
            </div>


                </dl>
              </div>
            </div>



    </div>
  )
}

export default userProfile