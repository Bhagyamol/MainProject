import React from 'react'
import {useState,useEffect} from 'react'
import UserNavbarHome from '../Components/userNavbarHome'
import UserNavbar from '../Components/userNavbar'
import Link from 'next/link'
function home() {

  const [user,setUser]=useState(false)

  useEffect(()=>{
    let user_id=localStorage.getItem("user_id")
    if(user_id){
      setUser(true)
 
    }
   },[])


  return (
    <div>
      {
      user?
      <UserNavbar/>:
         <UserNavbarHome/>

    }
   
    <div className="relative bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="relative z-10 pb-8 bg-white sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
          <svg className="hidden lg:block absolute right-0 inset-y-0 h-full w-48 text-white transform translate-x-1/2" fill="currentColor" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
            {/*<polygon points="50,0 100,0 50,100 0,100" />*/}
          </svg>
    
          <div>
            
          
            
            <div className="absolute z-10 top-0 inset-x-0 p-2 transition transform origin-top-right md:hidden">
              <div className="rounded-lg shadow-md bg-white ring-1 ring-black ring-opacity-5 overflow-hidden">
                <div className="px-5 pt-4 flex items-center justify-between">
                  <div>
                    <img className="h-8 w-auto" src="https://tailwindui.com/img/logos/workflow-mark-indigo-600.svg" alt=""/>
                  </div>
                  <div className="-mr-2">
                    <button type="button" className="bg-white rounded-md p-2 inline-flex items-center justify-center text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500">
                      <span className="sr-only">Close main menu</span>
                      
                      <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                </div>
                <div className="px-2 pt-2 pb-3 space-y-1">
                  <a href="#" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50">Home</a>
    
                  
                  <a href="#" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50">Signin</a>
    
                  <a href="#" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50">Signup</a>
                </div>
                {/* <a href="#" className="block w-full px-5 py-3 text-center font-medium text-indigo-600 bg-gray-50 hover:bg-gray-100"> Log in </a> */}
              </div>
            </div>
          </div>
    
          <main className="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
            <div className="sm:text-center lg:text-left">
              <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
                <span className="block xl:inline">SUBLET  </span>
               {/* <span className="block text-indigo-600 xl:inline">Rent a Room</span>*/}
              </h1>
              <p className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">We help finding Apartments,GuestHouses,Auditoriums for rent</p>
              
              <div className="mt-3 sm:mt-5 sm:flex sm:justify-center lg:justify-start">
              
                <div className="rounded-md shadow">
                
                  <a href="/Categories" className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 md:py-4 md:text-lg md:px-10"> 
                Explore  </a>
                  
                </div>
              
                
              </div>
            </div>
          </main>
          
        </div>
      </div>
      
     <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/1 mt-10" style={{marginRight:"50px",marginTop:"100px",borderRadius:"3px"}}>
        <img className="h-56 w-full object-cover sm:h-72 md:h-96 lg:w-full lg:h-full" src="https://wallpapercave.com/wp/wp8466031.jpg" alt=""/>
    </div> 
    </div>
    <div class="mt-6 bg-gray-50">
                  <div class=" px-10 py-6 mx-auto">
                        
                        {/* <!--author--> */}
                     <div class="max-w-6xl px-10 py-6 mx-auto bg-gray-50">
                        
		                <a href="#_" class="block transition duration-200 ease-out transform hover:scale-110">
	                        <img class="object-cover w-full shadow-sm h-full" src="https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8YmVhdXRpZnVsJTIwaG91c2V8ZW58MHx8MHx8&w=1000&q=80"/>
	                    </a>

		                
                 <div class="max-w-4xl px-10  mx-auto text-2xl text-gray-700 mt-4 rounded bg-gray-100">

                 	 </div>

                     

				        {/* </div> */}
				    {/* </div> */}
					<h2 class="text-2xl mt-4 text-gray-500 font-bold text-center">Explore</h2>
  <div class="max-w-7xl mx-auto px-5 mb-3">
  <div class="mt-6 grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-3 xl:gap-x-8">
            

            <div class="grid grid-cols-12 col-span-12 gap-7">
                <div class="flex flex-col items-start col-span-12 overflow-hidden shadow-sm rounded-xl md:col-span-6 lg:col-span-4">
                    <a href="#_" class="block transition duration-200 ease-out transform hover:scale-110">
                        <img class="object-cover w-full shadow-sm h-full" src="https://media.istockphoto.com/photos/modern-apartment-buildings-on-a-sunny-day-with-a-blue-sky-picture-id1177797403?k=20&m=1177797403&s=612x612&w=0&h=bfprQyZxMluJaAfl2NyzIndyJDOoNGgSh8eOegCsAB4="/>
                    </a>
                    <div class="relative flex flex-col items-start bg-white border border-t-0   rounded-b-2xl">
                        <div class="bg-indigo-400 absolute top-0 mb-5 -mt-3 ml-6 flex items-center px-3 py-1.5 leading-none w-auto inline-block rounded-full text-xs font-medium uppercase text-white inline-block">
                        <Link href="/Appartment"><span>Appartments</span></Link>
                        </div>
                        {/* <h2 class="text-base text-gray-500 font-bold sm:text-lg md:text-xl"><a href="#_">Oauth using facebook with flask,mysql,vuejs and tailwind css</a></h2> */}
                        {/* <!-- <p class="mt-2 text-sm text-gray-500">Learn how to authenticate users to your application using facebook.</p> --> */}
                    </div>
                </div>

                <div class="flex flex-col items-start col-span-12 overflow-hidden shadow-sm rounded-xl md:col-span-6 lg:col-span-4">
                    <a href="#_" class="block transition duration-200 ease-out transform hover:scale-110">
                        <img class="object-cover w-full shadow-sm h-full" src="https://static.wixstatic.com/media/3a88a3_76a568e470c640e4bef0d8699b8c8843~mv2.jpg/v1/fill/w_400,h_360,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/ilanda%20guesthouse%20-%20swimming%20pool%20%26%20lapp.jpg"/>
                    </a>
                    <div class="relative flex flex-col items-start mb-5  bg-white border border-t-0   ">
                        <div  class=" bg-red-400 absolute top-0  -mt-3 ml-6 flex items-center px-3 py-1.5 leading-none w-auto inline-block rounded-full text-xs font-medium uppercase text-white inline-block">
                        <Link href="/Guesthouses"><span>Guesthouses</span></Link>

                        </div>
                        {/* <h2 class="text-base text-gray-500 font-bold sm:text-lg md:text-xl"><a href="#_">Authenticating users with email verification in Django apps</a></h2> */}
                        {/* <!-- <p class="mt-2 text-sm text-gray-500">Learn how to authenticate users to your web application by sending secure links to their email box.</p> --> */}
                    </div>
                </div>

                <div class="flex flex-col items-start col-span-12 overflow-hidden shadow-sm rounded-xl md:col-span-6 lg:col-span-4">
                    <a href="#_" class="block transition duration-200 ease-out transform hover:scale-110">
                        <img class="object-cover w-full shadow-sm h-full" src="https://media.istockphoto.com/photos/empty-auditorium-with-grey-seats-and-downlights-picture-id157334256?k=20&m=157334256&s=612x612&w=0&h=CJ0CMOptG386n2g_9x32632RfxmkGr8CKI89a1hYkJI="/>
                    </a>
                    <div class="relative flex flex-col items-start bg-white border border-t-0   rounded-b-2xl">
                        <div class="bg-purple-500 absolute mb-5 top-0 ml-6 -mt-3 flex items-center px-3 py-1.5 leading-none w-auto inline-block rounded-full text-xs font-medium uppercase text-white inline-block">
                        <Link href="/Auditorium"><span>Auditoriam</span></Link>
                        </div>
                        {/* <h2 class="text-base text-gray-500 font-bold sm:text-lg md:text-xl"><a href="#_">Creating user registration and authentication system in flask</a></h2> */}
                        {/* <!-- <p class="mt-2 text-sm text-gray-500">Learn how to authenticate users to your application using flask and mysql db.</p> --> */}
                    </div>
                </div>
            </div>
            </div>
        </div>
        </div>
        </div>
        </div>
  

   
{/* <div style={{marginTop:"150px"}}>
<Footer/>
</div> */}
    </div>
    
 
    
  )
}

export default home
