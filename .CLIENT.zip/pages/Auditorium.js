import React from 'react'
import { styled, alpha } from '@mui/material/styles';
import AppBar from '@mui/material/AppBar';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import IconButton from '@mui/material/IconButton';
import Avatar from '@mui/material/Avatar';
import InputBase from '@mui/material/InputBase';
import MenuIcon from '@mui/icons-material/Menu';
//import MoreVertIcon from '@mui/icons-material/MoreVertIcon';
import {useState,useEffect} from 'react'
import{useRouter} from 'next/router'
import  UserNavbar from '../Components/userNavbar'
import axios from 'axios'
import Swal from 'sweetalert2'

const Search = styled('div')(({ theme }) => ({
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: alpha(theme.palette.common.white, 0.15),
    '&:hover': {
      backgroundColor: alpha(theme.palette.common.white, 0.25),
    },
    marginLeft: 0,
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(1),
      width: 'auto',
    },
  }));
  
  const SearchIconWrapper = styled('div')(({ theme }) => ({
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  }));
  
  const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: 'inherit',
    '& .MuiInputBase-input': {
      padding: theme.spacing(1, 1, 1, 0),
      // vertical padding + font size from searchIcon
      paddingLeft: `calc(1em + ${theme.spacing(4)})`,
      transition: theme.transitions.create('width'),
      width: '100%',
      [theme.breakpoints.up('sm')]: {
        width: '12ch',
        '&:focus': {
          width: '20ch',
        },
      },
    },
  }));
function Auditoriam() {
  const Toast = Swal.mixin({
    toast: true,
    position: "bottom-left",
    iconColor: "white",
    customClass: {
      popup: "colored-toast",
    },
    showConfirmButton: false,
    timer: 1500,
    timerProgressBar: true,
  });
    const [appartments,setAppartments]=useState([])
  
    const router = useRouter()
    
    useEffect(()=>{

      let u_id=localStorage.getItem('user_id')
    
        axios.get('http://localhost:5000/user/getallAuditoriums').then((resp)=>{
          if(resp.data.data){
             setAppartments(resp.data.data)
              console.log(resp.data.data);
          }
     }).catch((err)=>{
         console.log(err);

     })

      
    },[])

    const addTocart=(a_id)=>{
      let u_id=localStorage.getItem('user_id')
      if(u_id){

        axios.post('http://localhost:5000/user/addTocart',{u_id,a_id,type:"auditorium"}).then((resp)=>{
          if(resp.data.success==true){
            Toast.fire({
              icon: "success",
              title: " Added to favourites List successfully",
            });
          }
          else{
            console.log(resp.data);
          }

        })
      }
      else{
        router.push('/signin')
      }

    }
    const handleChange=(e,type)=>{

      let input=e.target.value;
      axios.post('http://localhost:5000/user/searchByloc',{input,type}).then((resp)=>{
        setAppartments(resp.data.data)
        
   })

}
  return (
<div>
  <UserNavbar/>
<div> <div class="flex space-x-2 justify-center mt-2">






<span onClick={() => { router.push('/Appartment') }} class="mt-2 px-4 py-2 rounded-full text-black bg-red-300 font-semibold text-sm flex align-center w-max cursor-pointer active:bg-red-100 transition duration-300 ease">Appartments</span>
<span onClick={() => { router.push('/Auditorium') }} class="mt-2 px-4 py-2 rounded-full text-black bg-red-300 font-semibold text-sm flex align-center w-max cursor-pointer active:bg-red-100 transition duration-300 ease">Auditorium</span>

</div>
<h3 class="font-medium leading-tight text-center text-xl mt-0  text-blue-600 pt-4">AUDITORIUMS</h3>
<div className="min-h-full flex items-center justify-center py-12 px-4 sm:px-6 lg:px-2">
           <div className="max-w-md w-full space-y-8 w-80">
         
           <input
                  id="pasword"
                  onChange={(e)=>{handleChange(e,2)}}
                  
                  required
                  className="mt-2 appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                  placeholder="Search auditorium by location...🔎"
            />
             <h5 class="font-medium leading-tight text-center text-xl mt-0  text-blue-600 ">
   <span class="text-sm inline-block py-1 px-3.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-blue-700 text-white rounded-full ml-5">{appartments.length>0? appartments.length+" "+"results found 😍":"No results found 😕"}</span>
             

</h5>

            </div>
            </div>  

           <div className="mt-1 grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
        {
            appartments.map((d)=>{
                return(
                  <div>
             
  <div className="group relative m-5">
  
  <div className="w-full min-h-60 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-50 lg:aspect-none">
    <img
      src={d.photo}
      className="w-full h-full object-center object-cover lg:w-full lg:h-full"
    />
  </div>
  <div className="mt-4 flex justify-between">
    <div>
      <h3 className="text-lg text-black-700">
        <a href={d.href}>
        <p className="text-base font-semibold text-gray-900">  {d.name}</p>
        <p className="mt-1 text-sm text-gray-500">{d.city}</p>
        <p className="mt-1 text-sm text-gray-500">{d.street}</p>
        <p className="mt-2 text-sm text-green-500">{d.type}</p>
        <p className="text-base font-semibold mt-2 text-sm text-red-500">Available Chairs: {d.no_chair}</p>
        {/* <p className="mt-1 text-sm text-gray-500">{d.google_map_url}/view map</p> */}
        {/* <p className="mt-1 text-sm text-gray-500">{"added by" +""+d.vendor_id}</p> */}

        
        </a>
      </h3>
      <div>
      <span 
       onClick={()=>{addTocart(d._id)}}
       class="text-xs inline-block  py-2 px-3.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-green-500 text-white rounded-full">❤️Add to Favourites❤️</span></div>

    </div>
   
    <p className="mt-1 text-lg font-medium text-gray-900">Rs.{d.price}/-Day</p>
   
  </div>
</div>
</div>
                )
            })
        }
        </div>
  
      </div> 
                </div>
  
              
  )
  
  }


export default Auditoriam
