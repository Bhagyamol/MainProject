import React from 'react'

function signup() {
  return (
    <div>signup</div>
  )
}

export default signup