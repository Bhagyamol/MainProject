var express = require("express");
var router = express.Router();
const user = require("../models/userModel");
const vendor =require("../models/vendorModel")
const appartment=require("../models/appartmentModel")
const rental = require("../models/rentalModel")
const address=require("../models/userAddress")
const guesthouse=require("../models/guesthousesModel")
const cart =require("../models/cartModel")
const mongoose =require("mongoose");
const auditorium = require("../models/auditoriumModel");
const { request } = require("express");
const sgMail = require('@sendgrid/mail');
sgMail.setApiKey("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");
const shortid = require("shortid");
const Razorpay = require("razorpay");

const razorpay = new Razorpay({
  key_id: "rzp_test_r4UiRnyA6pT6fY",
  key_secret: "bCLVwVdxZam7AUc8fzZi0a2B",
});
router.get("/", (req, res) => {
  console.log("Working fine");
  res.send("Working fine");
 
});
//razorpay
router.post("/razorpay", async (req, res) => {
  const payment_capture = 1;
  const amount =req.body.total*100;
  const currency = "INR";
console.log(req.body);
  const options = {
    amount,
    currency,
    receipt: shortid.generate(),
    payment_capture,
  };

  try {
    const response = await razorpay.orders.create(options);
    console.log(response);
    res.json({
      id: response.id,
      currency: response.currency,
      amount: response.amount,
    });
  } catch (error) {
    console.log(error);
  }
});

//*user routes*

//user signin
router.post("/user/signin", (req, res) => {
  let userObj = req.body;

  user.findOne({ email: userObj.email }).then((data) => {
    if (data && data.password == userObj.password) {
      res.json({
        success: true,
        user_id: data._id,
      });
    } else {
      res.json({
        success: false,
        message: "Invalid credentials..!!",
      });
    }
  });
});

//vendor signin
router.post("/vendor/signin", (req, res) => {
  let vendorObj = req.body;

  vendor.findOne({ email: vendorObj.email }).then((data) => {
    if (data && data.password == vendorObj.password) {
      res.json({
        success: true,
        vendor_id: data._id,
      });
    } else {
      res.json({
        success: false,
        message: "Invalid credentials..!!",
      });
    }
  });
});
//user signup
router.post("/user/signup", (req, res) => {
  let userObj = req.body;

  user
    .findOne({ email: userObj.email })
    .then((data) => {
      if (data) {
        res.json({
          success: false,
          message: "User with this mail id already exist..!!",
        });
      } else {
        let usr = {
          name: userObj.name,
          email: userObj.email,
          phone: userObj.phone,
          password: userObj.password,
          date_joined: Date.now(),
        };
        user
          .create(usr)
          .then((data_2) => {
            if (data_2) {
              res.json({ success: true, user_id: data_2._id });
            } else {
              res.json({ success: false, message: "Something went wrong..!!" });
            }
          })
          .catch((err) => {
            res.json({ success: false, message: "Something went wrong..!!" });
          });
      }
    })
    .catch((err) => {
      res.json({ success: false, message: "Something went wrong..!!" });
    });
});
//vendor signup

router.post("/vendor/signup", (req, res) => {
  let vendorObj = req.body;

  vendor
    .findOne({ email: vendorObj.email })
    .then((data) => {
      if (data) {
        res.json({
          success: false,
          message: "Vendor with this mail id already exist..!!",
        });
      } else {
        let usr = {
          name: vendorObj.name,
          email: vendorObj.email,
          phone: vendorObj.phone,
          password: vendorObj.password,
          date_joined: Date.now(),
          is_approved:false,
        };
        vendor
          .create(usr)
          .then((data_2) => {
            if (data_2) {
              res.json({ success: true, vendor_id: data_2._id });
            } else {
              res.json({ success: false, message: "Something went wrong..!!" });
            }
          })
          .catch((err) => {
            res.json({ success: false, message: "Something went wrong..!!" });
          });
      }
    })
    .catch((err) => {
      res.json({ success: false, message: "Something went wrong..!!" });
    });
});
//add address
router.post('/user/addAddress',(req,res)=>{
  var ad=req.body.address;
  var user_id=req.body.u_id;
  let obj={
  user_id:user_id,
  house_name:ad.house_name,
  district: ad.district,
  state: ad.state,
  country:ad.country ,
  city: ad.city,
  street:ad.street ,
  postal_code:ad.postal_code,
  }

  address.create(obj).then((resp)=>{
    if(resp){
      console.log(resp);
      res.json({success:true})
    }else{
      console.log("inside");
      res.json({success:false})
    }
  }).catch((err)=>{
    console.log(err);
  })
})
//get user details

router.post('/user/getUser',(req,res)=>{
  console.log(req.body);
  user.findOne({_id:req.body.user_id}).then((data)=>{
    
    if(data){
      address.findOne({user_id:req.body.user_id}).then((d)=>{
        if(d){
          res.json({success:true,user:data,address:d})

        }
      })
    }
    else{
      res.json({success:false})
    }

  })
})

router.post('/vendor/getVendor',(req,res)=>{
  console.log(req.body);
  vendor.findOne({_id:req.body.vendor_id}).then((data)=>{
    
    if(data){
      let earn=0;
      let earn1=0;
      let earn2=0;
      
      rental.find({vendor_id:req.body.vendor_id}).then((d)=>{
      
        appartment.find({vendor_id:req.body.vendor_id}).then((d2)=>{
           
          d.map((n)=>{
            let no_days=n.no_days;
              d2.map((e)=>{
                if(n.appartment_id==e._id){
                  earn=earn+(e.price*no_days)
                }
               
              })
              
          })

          auditorium.find({vendor_id:req.body.vendor_id}).then((d3)=>{
           console.log(d3);
            d.map((n)=>{
              let no_days=n.no_days;
                d3.map((e)=>{
                  if(n.appartment_id==e._id){
                    earn1=earn1+(e.price*no_days)
                  }
                 
                })
                
            })

            guesthouse.find({vendor_id:req.body.vendor_id}).then((d4)=>{
              console.log(d3);
               d.map((n)=>{
                 let no_days=n.no_days;
                   d4.map((e)=>{
                     if(n.appartment_id==e._id){
                       earn2=earn2+(e.price*no_days)
                     }
                    
                   })
                   
               })
          res.json({success:true,vendor:data,rentals:d,appartments:d2,auditoriums:d3,guesthouses:d4, earnings:earn,earn1,earn2})
                   
              })

           




          })
        })
      })
      
    }
    else{
      res.json({success:false})
    }

  })
})

//add appartment
router.post('/vendor/add-appartment',(req,res)=>{
   console.log(req.body);
   let ap=req.body.appartment;
   let obj={
    vendor_id:req.body.vendor_id,
    name:ap.name,
    photo:ap.photo,
    address:ap.address,
    phone:ap.phone,
    no_rooms:ap.no_rooms,
    city:ap.city,
    pincode:ap.pincode,
    street:ap.street,
    price:ap.rate,
    google_map_url:ap.google_map_url,
    is_booked:false,
    no_of_bookings:0,
    type:"Appartment",

   }
   appartment.create(obj).then((data)=>{
     if(data){
      res.json({success:true})
     }
     else{
      res.json({success:false})      
     }
   }).catch((err)=>{
      res.json({success:false})
   })
  
})

// vendor add auditorium
router.post('/vendor/add-auditorium',(req,res)=>{
  console.log(req.body);
  let ap=req.body.auditorium;
  let obj={
   vendor_id:req.body.vendor_id,
   name:ap.name,
   photo:ap.photo,
   address:ap.address,
   phone:ap.phone,
   no_chair:ap.no_chair,
   city:ap.city,
   pincode:ap.pincode,
   street:ap.street,
   price:ap.rate,
   google_map_url:ap.google_map_url,
   is_booked:false,
   no_of_bookings:0,
   type:"Auditorium",

  }
  auditorium.create(obj).then((data)=>{
    if(data){
     res.json({success:true})
    }
    else{
     res.json({success:false})      
    }
  }).catch((err)=>{
     res.json({success:false})
  })
 
})

// vndor add guesthouses
router.post('/vendor/add-guesthouses',(req,res)=>{
  console.log(req.body);
  let ap=req.body.guesthouses;
  let obj={
   vendor_id:req.body.vendor_id,
   name:ap.name,
   photo:ap.photo,
   address:ap.address,
   phone:ap.phone,
   no_rooms:ap.no_rooms,
   city:ap.city,
   pincode:ap.pincode,
   street:ap.street,
   price:ap.rate,
   google_map_url:ap.google_map_url,
   is_booked:false,
   no_of_bookings:0,
   type:"Guesthouse",

  }
  console.log(obj);
  guesthouse.create(obj).then((data)=>{
    if(data){
     res.json({success:true})
    }
    else{
     res.json({success:false})      
    }
  }).catch((err)=>{
     res.json({success:false})
  })
 
})
//view all users

router.get('/admin/getAllusers',(req,res)=>{
  user.find({}).then((data)=>{
    if(data){
      res.json({success:true,users:data})
    }
    else{
      res.json({success:false})
    }
  }).catch((err)=>{
      res.json({success:false})
       
  })
})

router.get('/admin/getAllvendors',(req,res)=>{
  vendor.find({}).then((data)=>{
    if(data){
      res.json({success:true,vendors:data})
    }
    else{
      res.json({success:false})
    }
  }).catch((err)=>{
      res.json({success:false})
       
  })
})
//get rentals


router.post('/vendor/getRentals',(req,res)=>{
  console.log(req.body.v_id);

  appartment.find({vendor_id:req.body.v_id}).then((d1)=>{
    if(d1){
      auditorium.find({vendor_id:req.body.v_id}).then((d2)=>{
          if(d2){
            guesthouse.find({vendor_id:req.body.v_id}).then((d3)=>{
              res.json({success:true,rentals:d1,auditoriums:d2,guesthouses:d3})
                
            })
          }
      })
      
    }
    else{
      res.json({success:false})
    }
  }).catch((err)=>{
      res.json({success:false})
       
  })
})
//get bookings
router.post('/vendor/getBookings',(req,res)=>{
  console.log(req.body.v_id);
  rental.find({vendor_id:req.body.v_id}).then((r)=>{
    console.log(r);
    if(r){
      var bookings=[]

      user.find({}).then((u)=>{
          r.map((rent)=>{
            u.map((usr)=>{
              console.log(rent.user_id,usr._id.toString());
              let u_id=usr._id.toString()
              if(rent.user_id==u_id)   {
                console.log("inside");
                let obj=
                {
                 rent,
                 usr
                }
                bookings.push(obj)
                console.log(bookings);
              }
            })
          })
          res.json({success:true,bookings})
      })

    //  console.log(bookings);
     
      
    }
    else{
      res.json({success:false})
    }

  })

})

router.get('/user/getallGuesthouses',(req,res)=>{
   guesthouse.find({is_booked:false}).then((data)=>{
   if(data){
    res.json({success:true,data:data})
   }
   else{
    res.json({success:false})

   }
   })
})
router.get('/user/getallAuditoriums',(req,res)=>{
  auditorium.find({is_booked:false}).then((data)=>{
  if(data){
   res.json({success:true,data:data})
  }
  else{
   res.json({success:false})

  }
  })
})
//view all apartment/guesthouse/auditorium
router.get('/user/getallAppartments',(req,res)=>{
  appartment.find({}).then((data)=>{
    if(data){

       rental.find({}).then((r)=>{
         r.map((i)=>{
           data.map((j)=>{
            
               if(i.appartment_id==j._id){
                  let no_days_left=i.no_days_left
                  if(no_days_left==0 && i.is_vacated==false){
                    appartment.findOneAndUpdate({_id:j._id},{is_booked:false},{useFindAndModify:false}).then((d1)=>{
                      rental.findOneAndUpdate({appartment_id:j._id},{is_vacated:true}).then((r)=>{
                         console.log("vacated");
                      })
                    });
                  }
                  else{
                    //  console.log("inside");
                    //  console.log(i.no_days_left);
                    //  let date_t=new Date(i.date_to);
                    //  let diff=Math.round(date_t.getTime()-(new Date().getTime())/(1000 * 3600 * 24))+1
                    //  console.log(diff);
                    //  if(diff>=0){
                    let date_t=new Date(i.date_to);
                    if(new Date()>=new Date(i.date_from) &&(i.is_vacated==false)){
                      console.log("inside 2");

                      let Difference_In_Time=date_t.getTime()-(new Date().getTime())
                      let Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
                      let no_days_left=Math.round(Difference_In_Days)+1;
                      // 
                    console.log(no_days_left);
                    if(no_days_left<1){
                      rental.findOneAndUpdate({appartment_id:j._id},{no_days_left:0},{useFindAndModify:false}).then((res)=>{
                        
                        rental.findOneAndUpdate({appartment_id:j._id},{is_vacated:true}).then((r)=>{
                          appartment.findByIdAndUpdate({_id:i.appartment_id},{is_booked:false},{useFindAndModify:false}).then((d3)=>{

                            console.log("vacated 2");
                          })
                        })
                      })
                        
                    }
                    else{
                      rental.findOneAndUpdate({appartment_id:j._id},{no_days_left:no_days_left},{useFindAndModify:false}).then((res)=>{
                        // console.log("done");
                      })
  
                    }
                    }
                   
                    //  }
                  }
               }
           })
         })
       })

   appartment.find({is_booked:false}).then((d)=>{
    if(d){
      res.json({success:true,data:d})
    }
    else{
      res.json({success:false})
   }
  })


       
    }
    else{
      res.json({success:false})
    }
  })
})
//approve vendor

router.post('/admin/approve',(req,res)=>{
  vendor.findOneAndUpdate({_id:req.body.v_id},{is_approved:true},{useFindAndModify:false }).then((data)=>{
    if(data){
      console.log(data);

      const msg = { 
        to: data.email,
        from: 'bhagyamolmadhu2022@mca.sjcetpalai.ac.in', // Use the email address or domain you verified above
        subject: 'SUBLET :Profile verified',
        text: `Hello ${data.name} your profile has been verified ,you can now start posting rentals..`,
        html: `<strong>Hello ${data.name} your profile has been verified ,you can now start posting rentals..</strong>`,
      };
      //ES6
      sgMail
        .send(msg)
        .then(() => {}, error => {
          console.error(error);
      
          if (error.response) {
            console.error(error.response.body)
          }
        });
      //ES8
      (async () => {
        try {
          await sgMail.send(msg);
          res.json({success:true})
        } catch (error) {
          console.error(error);
      
          if (error.response) {
            console.error(error.response.body)
          }
        }
      })();

      
    }
    else{
      res.json({success:false})
    }
  }).catch((err)=>{
      res.json({success:false})
       
  })
})

//cancel vendor
router.post('/admin/cancel',(req,res)=>{
  vendor.findOneAndUpdate({_id:req.body.v_id},{is_approved:false},{useFindAndModify:false }).then((data)=>{
    if(data){
      res.json({success:true})
    }
    else{
      res.json({success:false})
    }
  }).catch((err)=>{
      res.json({success:false})
       
  })
})
//admin get all apppartments
router.get('/admin/getAllapartments',(req,res)=>{
  appartment.find({}).then((d)=>{
    

    if(d){
      vendor.find({}).then((v)=>{
        let appartmentArray=[]
        d.map((aprtmnt)=>{
          v.map((vndr)=>{
            let v_id=vndr._id.toString();
            console.log(v_id);
            if(aprtmnt.vendor_id==v_id){
              let obj={
                aprtmnt,
                vndr
              }
              appartmentArray.push(obj)
            }
          })
        })
       console.log(appartmentArray);
        res.json({success:true,data:appartmentArray})
      })

    }
    else{
      res.json({success:false})
      
    }
  }).catch((err)=>{
      res.json({success:false})
        
  })
})
router.get('/admin/getAllauditoriums',(req,res)=>{
  auditorium.find({}).then((d)=>{
    

    if(d){
      vendor.find({}).then((v)=>{
        let appartmentArray=[]
        d.map((aprtmnt)=>{
          v.map((vndr)=>{
            let v_id=vndr._id.toString();
            console.log(v_id);
            if(aprtmnt.vendor_id==v_id){
              let obj={
                aprtmnt,
                vndr
              }
              appartmentArray.push(obj)
            }
          })
        })
       console.log(appartmentArray);
        res.json({success:true,data:appartmentArray})
      })

    }
    else{
      res.json({success:false})
      
    }
  }).catch((err)=>{
      res.json({success:false})
        
  })
})

router.get('/admin/getAllguesthouses',(req,res)=>{
  guesthouse.find({}).then((d)=>{
    

    if(d){
      vendor.find({}).then((v)=>{
        let appartmentArray=[]
        d.map((aprtmnt)=>{
          v.map((vndr)=>{
            let v_id=vndr._id.toString();
            console.log(v_id);
            if(aprtmnt.vendor_id==v_id){
              let obj={
                aprtmnt,
                vndr
              }
              appartmentArray.push(obj)
            }
          })
        })
       console.log(appartmentArray);
        res.json({success:true,data:appartmentArray})
      })

    }
    else{
      res.json({success:false})
      
    }
  }).catch((err)=>{
      res.json({success:false})
        
  })
})

//admin get all renders
router.get('/admin/getAllrentals',(req,res)=>{
  // rental.find({}).then((d)=>{

  //   if(d){
  //      res.json({success:true,data:d})
  //   }
  //   else{
  //      res.json({success:false})
      
  //   }
  // }).catch((err)=>{
  //     res.json({success:false})
        
  // })

  rental.find({}).then((r)=>{
    console.log(r);
    if(r){
      var bookings=[]

      user.find({}).then((u)=>{
        vendor.find({}).then((v)=>{

          r.map((rent)=>{
            u.map((usr)=>{
              v.map((vdr)=>{
                let u_id=usr._id.toString()
                let v_id=vdr._id.toString()
                if(rent.user_id==u_id &&rent.vendor_id==v_id)   {
                  console.log("inside");
                  let obj=
                  {
                   rent,
                   usr,
                   vdr
                  }
                  bookings.push(obj)
                  console.log(bookings);
                }
  
              })
             
            })
          })
          res.json({success:true,data:bookings})
          
        })
       
          
          
      })

    //  console.log(bookings);
     
      
    }
    else{
      res.json({success:false})
    }

  })
})

//serach by loaction 
router.post('/user/searchByloc',(req,res)=>{
  console.log(req.body.input);
  if(req.body.type==1){
    appartment.find({city:{$regex:req.body.input}}).then((data)=>{
      if(data){
        res.json({success:true,data:data})
      }
      else{
        res.json({success:false})
      }
    })
  }else if (req.body.type==2){
    auditorium.find({city:{$regex:req.body.input}}).then((data)=>{
      if(data){
        res.json({success:true,data:data})
      }
      else{
        res.json({success:false})
      }
    })
  }else if (req.body.type==3){
    guesthouse.find({city:{$regex:req.body.input}}).then((data)=>{
      if(data){
        res.json({success:true,data:data})
      }
      else{
        res.json({success:false})
      }
    })
  }



  
})
//add to cart
router.post('/user/addTocart',(req,res)=>{
  console.log(req.body);

 

    cart.findOne({user_id:req.body.u_id,type:req.body.type}).then((data)=>{
     // console.log(data);
     if(data){
      if(req.body.type=="appartment"){
        let arr=data.items
        appartment.findOne({_id:req.body.a_id}).then((ap)=>{
          if(ap){
           
            arr.push(ap)
           
            cart.findOneAndUpdate({user_id:req.body.u_id,type:"appartment"},{items:arr},{useFindAndModify:false}).then((dat)=>{
              if(dat){
                console.log(dat);
                res.json({success:true})
              }
              else{
                res.json({success:"1"})
  
              }
            }).catch((err)=>{
              res.json({success:"2"})
  
            })
          }
          else{
            res.json({success:"3"})

          }
        }).catch((err)=>{
          res.json({success:"4"})

        })
        
    }
    else if(req.body.type=="auditorium"){
      console.log("inside audi");
      let arr=data.items
      auditorium.findOne({_id:req.body.a_id}).then((ap)=>{
        if(ap){
         
          arr.push(ap)
         
          cart.findOneAndUpdate({user_id:req.body.u_id,type:"auditorium"},{items:arr},{useFindAndModify:false}).then((dat)=>{
            if(dat){
              console.log(dat);
              res.json({success:true})
            }
            else{
              res.json({success:"5"})

            }
          }).catch((err)=>{
            res.json({success:"6"})

          })
        }
        else{
          res.json({success:"7"})

        }
      }).catch((err)=>{
        res.json({success:"8"})

      })
    }
    else if(data.type=="guesthouse"){
      console.log("inside");
      let arr=data.items
      guesthouse.findOne({_id:req.body.a_id}).then((ap)=>{
        if(ap){
         
          arr.push(ap)
         
          cart.findOneAndUpdate({user_id:req.body.u_id,type:"guesthouse"},{items:arr},{useFindAndModify:false}).then((dat)=>{
            if(dat){
              console.log(dat);
              res.json({success:true})
            }
            else{
              res.json({success:"9"})

            }
          }).catch((err)=>{
            res.json({success:"10"})

          })
        }
        else{
          res.json({success:"11"})

        }
      }).catch((err)=>{
        res.json({success:"12"})

      })
    }
    
     }
      
      else {

        console.log("No cart");
        let temp;
        if(req.body.type=="appartment"){
          temp=appartment;
          
        }
        else if(req.body.type=="guesthouse"){
          temp=guesthouse;
        }
        else if(req.body.type=="auditorium"){
         
          temp=auditorium;
        }

         console.log(temp,req.body.a_id);
        temp.findOne({_id:req.body.a_id}).then((ap)=>{
          console.log(ap);
          if(ap){
            let arr=[]
            arr.push(ap)
            let obj={
              user_id:req.body.u_id,
              type:req.body.type,
              items:arr
            }
            cart.create(obj).then((dat)=>{
              if(dat){
                console.log(dat);
                res.json({success:true})
              }
              else{
                res.json({success:"13"})
  
              }
            }).catch((err)=>{
              res.json({success:"14"})
  
            })
          }
          else{
            res.json({success:"15"})
  
          }
        }).catch((err)=>{
          res.json({success:"16"})
  
        })
       
      }
    }).catch((err)=>{
      res.json({success:"17"})
  
    })

  




  
})

//get cart items
router.post('/user/getCartItems',(req,res)=>{
  console.log(req.body.u_id);
  cart.find({user_id:req.body.u_id}).then((data)=>{
    if(data){
      console.log(data);
      res.json({success:true,items:data})
    }
    else{
      res.json({success:false})
    }
  }).catch((err)=>{
    res.json({success:false})

  })

})

//remove cart item
router.post('/user/removeFromCart',(req,res)=>{
  console.log(req.body);
  let cart_id=mongoose.Types.ObjectId(req.body.c_id)
  let item_id=mongoose.Types.ObjectId(req.body.item_id);
  console.log(cart_id);
  cart.updateOne({_id:cart_id},{$pull:{items:{_id:item_id}}}).then((data)=>{
    console.log(data);
    if(data.modifiedCount===1){
      res.json({success:true})
     
    }
    else{
      res.json({success:false})
      
    }

  }).catch((err)=>{
    console.log(err);
  })
})

//view apartment/guesthouse/auditorium
//book apartment/guesthouse/auditorium
router.post('/user/book-appartment',(req,res)=>{

   

  console.log(req.body);
  let ap=req.body.ap
  let total_price=(req.body.d)*ap.price
  let date_f = req.body.dateFrom
  let date_t = req.body.dateTo;
  let Difference_In_Time = new Date(date_t).getTime() - new Date(date_f).getTime();
  
  let Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
  let no_days_left=Math.round(Difference_In_Days)+1;
  console.log(no_days_left);
  console.log(req.body.rtype);
  
  let obj={
    user_id:req.body.user_id,
    appartment_id:ap._id,
    appartment_name:ap.ap_name,
    type:ap.type,
    vendor_id:ap.vendor_id,
    date_from:req.body.dateFrom,
    date_to:req.body.dateTo,
    payment_status:true,
    total_price:total_price,
    no_days:req.body.d,
    no_days_left:no_days_left,
    is_vacated:false
  }
  // const options = {
  //   obj.total_price,
  //   currency,
  //   receipt: shortid.generate(),
  //   payment_capture,
  // };

  // try {
  //   const response = await razorpay.orders.create(options);
  //   console.log(response);
  //   res.json({
  //     id: response.id,
  //     currency: response.currency,
  //     amount: response.amount,
  //   });
  // } catch (error) {
  //   console.log(error);
  // }

  //if appartment
  if(req.body.rtype=="appartment"){
    rental.create(obj).then((data)=>{
      if(data){
        let cart_id=mongoose.Types.ObjectId(req.body.cart_id)
        let item_id=mongoose.Types.ObjectId(req.body.item_id)
        console.log(req.body.user_id,cart_id);
        cart.updateOne({_id:cart_id},{$pull:{items:{_id:item_id}}}).then((data1)=>{
      
          if(data1.modifiedCount===1){
           
           
             
            appartment.updateOne({_id:ap._id},{$inc:{no_of_bookings:1},$set:{is_booked:true}}).then((result)=>{
              console.log(result);
              if(result.modifiedCount===1){
                res.json({success:true})
              }
              else{
                res.json({success:false})
  
              }
              
            })
           
          }
          else{
            res.json({success:false})
  
          }
      
        })
       
        //res.json({success:true})
      }
      else{
        res.json({success:false})
      }
    }).catch((err)=>{
     
        res.json({success:false})
     
    })
  
    
  }

  else if(req.body.rtype=="auditorium"){
    rental.create(obj).then((data)=>{
      if(data){
        let cart_id=mongoose.Types.ObjectId(req.body.cart_id)
        let item_id=mongoose.Types.ObjectId(req.body.item_id)
        console.log(req.body.user_id,cart_id);
        cart.updateOne({_id:cart_id},{$pull:{items:{_id:item_id}}}).then((data1)=>{
      
          if(data1.modifiedCount===1){
           
            auditorium.updateOne({_id:ap._id},{$inc:{no_of_bookings:1},$set:{is_booked:true}}).then((result)=>{
              console.log(result);
              if(result.modifiedCount===1){
                res.json({success:true})
              }
              else{
                res.json({success:false})
  
              }
              
            })
           
          }
          else{
            res.json({success:false})
  
          }
      
        })
       
        //res.json({success:true})
      }
      else{
        res.json({success:false})
      }
    }).catch((err)=>{
     
        res.json({success:false})
     
    })
  }
  else if(req.body.rtype=="guesthouse"){
  console.log(req.body.rtype);
    rental.create(obj).then((data)=>{
      if(data){
        let cart_id=mongoose.Types.ObjectId(req.body.cart_id)
        let item_id=mongoose.Types.ObjectId(req.body.item_id)
        console.log(req.body.user_id,cart_id);
        cart.updateOne({_id:cart_id},{$pull:{items:{_id:item_id}}}).then((data1)=>{
      
          if(data1.modifiedCount===1){
           
            guesthouse.updateOne({_id:ap._id},{$inc:{no_of_bookings:1},$set:{is_booked:true}}).then((result)=>{
              console.log(result);
              if(result.modifiedCount===1){
                res.json({success:true})
              }
              else{
                res.json({success:"1"})
  
              }
              
            })
           
          }
          else{
            res.json({success:"2"})
  
          }
      
        })
       
        //res.json({success:true})
      }
      else{
        res.json({success:"3"})
      }
    }).catch((err)=>{
     
        res.json({success:"4"})
     
    })
  }

  
  
})
//view my rentals

router.post('/user/my-rentals_ap',(req,res)=>{
  let arr=[]
  let arr2=[]
  rental.find({user_id:req.body.user_id,is_vacated:false}).then((d)=>{

    if(d){

      appartment.find({}).then((ap)=>{
        ap.map((a)=>{
          d.map((r)=>{

            if(a._id==r.appartment_id){
              console.log("inside");
              let obj={a,r}
              arr.push(obj)
              
            }
          })
        })
      console.log(arr);
      rental.find({user_id:req.body.user_id,is_vacated:true}).then((d1)=>{
        appartment.find({}).then((ap)=>{
          ap.map((a)=>{
            d1.map((r)=>{
  
              if(a._id==r.appartment_id){
                console.log("inside");
                let obj={a,r}
                arr2.push(obj)
                
              }
            })
          })
          res.json({success:true,data:arr,vacated:arr2})
        })
      }
        
      )

       
      })
     
      
    }
  })
})


router.post('/user/my-rentals_au',(req,res)=>{
  let arr=[]
  let arr2=[]
  rental.find({user_id:req.body.user_id,is_vacated:false}).then((d)=>{

    if(d){

      auditorium.find({}).then((ap)=>{
        ap.map((a)=>{
          d.map((r)=>{

            if(a._id==r.appartment_id){
              console.log("inside");
              let obj={a,r}
              arr.push(obj)
              
            }
          })
        })
      console.log(arr);
      rental.find({user_id:req.body.user_id,is_vacated:true}).then((d1)=>{
        auditorium.find({}).then((ap)=>{
          ap.map((a)=>{
            d1.map((r)=>{
  
              if(a._id==r.appartment_id){
                console.log("inside");
                let obj={a,r}
                arr2.push(obj)
                
              }
            })
          })
          res.json({success:true,data:arr,vacated:arr2})
        })
      }
        
      )

       
      })
     
      
    }
  })
})
router.post('/user/my-rentals_gu',(req,res)=>{
  let arr=[]
  let arr2=[]
  rental.find({user_id:req.body.user_id,is_vacated:false}).then((d)=>{

    if(d){

      guesthouse.find({}).then((ap)=>{
        ap.map((a)=>{
          d.map((r)=>{

            if(a._id==r.appartment_id){
              console.log("inside");
              let obj={a,r}
              arr.push(obj)
              
            }
          })
        })
      console.log(arr);
      rental.find({user_id:req.body.user_id,is_vacated:true}).then((d1)=>{
        guesthouse.find({}).then((ap)=>{
          ap.map((a)=>{
            d1.map((r)=>{
  
              if(a._id==r.appartment_id){
                console.log("inside");
                let obj={a,r}
                arr2.push(obj)
                
              }
            })
          })
          res.json({success:true,data:arr,vacated:arr2})
        })
      }
        
      )

       
      })
     
      
    }
  })
})


//*vendor routes*

//add  apartment/guesthouse/auditorium

//edit apartment/guesthouse/auditorium

//delete apartment/guesthouse/auditorium
router.post('/vendor/deleteRental',(req,res)=>{
  console.log(req.body.type);
   let a_id=mongoose.Types.ObjectId(req.body.id)
  if(req.body.type==1){
    appartment.findOneAndDelete({_id:a_id}).then((d)=>{
      if(d){
        res.json({success:true})
       
      }
    })
  }else if(req.body.type==2){
    auditorium.findOneAndDelete({_id:a_id}).then((d)=>{
      if(d){
      res.json({success:true})
       
      }
    })
  }
  else  if(req.body.type==3){
    guesthouse.findOneAndDelete({_id:a_id}).then((d)=>{
      if(d){
        console.log(d);
      res.json({success:true})
            
      }
    })
  } 
 
})


router.post('/user/delete-rental',(req,res)=>{
  console.log(req.body.id);
  let today=new Date().toDateString();
  console.log(today);
  rental.findOneAndUpdate({_id:req.body.id},{"$set":{is_vacated:true,no_days_left:0,date_to:today}}).then((d)=>{
    if(d){
      if(req.body.type==1){
        appartment.findOneAndUpdate({_id:d.appartment_id},{is_booked:false}).then((resp)=>{
          res.json({success:true})
        }
        )
      }
      else if(req.body.type==2){
        auditorium.findOneAndUpdate({_id:d.appartment_id},{is_booked:false}).then((resp)=>{
          res.json({success:true})
        }
        )
      }
      else if(req.body.type==3){
        guesthouse.findOneAndUpdate({_id:d.appartment_id},{is_booked:false}).then((resp)=>{
          res.json({success:true})
        }
        )
      }
          
     
    }
  })
 
})

//*admin routes*

//view all users

//view all vendors

//approve items uploaded by vendor

//view all apartment/guesthouse/auditorium

//view apartment/guesthouse/auditorium

//view all rentals

module.exports = router;
