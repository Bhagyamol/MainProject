const sgMail = require('@sendgrid/mail');
sgMail.setApiKey(process.env.APIKEY);

 


module.exports={

doSignin:()=>{
  
   

},

doSignup:async()=>{
  
  

},


}