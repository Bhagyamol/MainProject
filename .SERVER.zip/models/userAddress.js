const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const addressSchema = new Schema({
  user_id:String,
  house_name: { type: String },
  district: { type: String },
  state: { type: String, default: null },
  country: { type: String, default: null },
  city: { type: String, default: null },
  street: { type: String, default: null },
  postal_code: { type: Number, default: null },
});
const address = mongoose.model("address", addressSchema);
module.exports = address;
